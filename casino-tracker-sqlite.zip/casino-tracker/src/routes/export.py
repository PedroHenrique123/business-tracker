from flask import Blueprint, jsonify, request, send_file
from datetime import datetime
import csv
import os
import json
import tempfile
import pandas as pd
from src.models.transaction import db, Transaction, Casino, Category

export_bp = Blueprint('export', __name__)

@export_bp.route('/export/transactions', methods=['GET'])
def export_transactions():
    """Exporta transações para CSV, Excel ou JSON"""
    try:
        # Parâmetros
        format_type = request.args.get('format', default='csv', type=str)
        start_date = request.args.get('start_date', type=str)
        end_date = request.args.get('end_date', type=str)
        casino_id = request.args.get('casino_id', type=int)
        
        # Construir query base
        query = Transaction.query.join(Casino)
        
        # Aplicar filtros
        if start_date:
            query = query.filter(Transaction.date >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(Transaction.date <= datetime.fromisoformat(end_date))
        if casino_id:
            query = query.filter(Transaction.casino_id == casino_id)
        
        # Ordenar por data
        query = query.order_by(Transaction.date.desc())
        
        # Executar query
        transactions = query.all()
        
        # Preparar dados para exportação
        export_data = []
        for transaction in transactions:
            category_name = transaction.category.name if transaction.category else ''
            
            export_data.append({
                'ID': transaction.id,
                'Data': transaction.date.strftime('%d/%m/%Y %H:%M'),
                'Valor': transaction.amount,
                'Casa de Apostas': transaction.casino.name,
                'Categoria': category_name,
                'Observações': transaction.notes or ''
            })
        
        # Criar arquivo temporário
        temp_file = tempfile.NamedTemporaryFile(delete=False)
        
        # Exportar no formato solicitado
        if format_type == 'csv':
            # Criar CSV
            with open(temp_file.name, 'w', newline='', encoding='utf-8') as csvfile:
                fieldnames = ['ID', 'Data', 'Valor', 'Casa de Apostas', 'Categoria', 'Observações']
                writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                
                writer.writeheader()
                for row in export_data:
                    writer.writerow(row)
            
            # Enviar arquivo
            return send_file(
                temp_file.name,
                as_attachment=True,
                download_name=f'transacoes_{datetime.now().strftime("%Y%m%d")}.csv',
                mimetype='text/csv'
            )
            
        elif format_type == 'excel':
            # Criar Excel com pandas
            df = pd.DataFrame(export_data)
            df.to_excel(temp_file.name, index=False)
            
            # Enviar arquivo
            return send_file(
                temp_file.name,
                as_attachment=True,
                download_name=f'transacoes_{datetime.now().strftime("%Y%m%d")}.xlsx',
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            
        elif format_type == 'json':
            # Criar JSON
            with open(temp_file.name, 'w', encoding='utf-8') as jsonfile:
                json.dump(export_data, jsonfile, ensure_ascii=False, indent=2)
            
            # Enviar arquivo
            return send_file(
                temp_file.name,
                as_attachment=True,
                download_name=f'transacoes_{datetime.now().strftime("%Y%m%d")}.json',
                mimetype='application/json'
            )
            
        else:
            return jsonify({'error': 'Formato não suportado. Use csv, excel ou json.'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        # Limpar arquivo temporário
        if 'temp_file' in locals():
            os.unlink(temp_file.name)

@export_bp.route('/export/summary', methods=['GET'])
def export_summary():
    """Exporta relatório resumido com estatísticas"""
    try:
        # Parâmetros
        format_type = request.args.get('format', default='pdf', type=str)
        period = request.args.get('period', default='month', type=str)
        
        # Definir data inicial com base no período
        today = datetime.now().date()
        if period == 'week':
            start_date = datetime.combine(today - timedelta(days=today.weekday()), datetime.min.time())
            period_name = 'Semana Atual'
        elif period == 'month':
            start_date = datetime.combine(datetime(today.year, today.month, 1), datetime.min.time())
            period_name = 'Mês Atual'
        elif period == 'year':
            start_date = datetime.combine(datetime(today.year, 1, 1), datetime.min.time())
            period_name = 'Ano Atual'
        else:
            # Período personalizado (dias)
            days = int(period)
            start_date = datetime.now() - timedelta(days=days)
            period_name = f'Últimos {days} dias'
        
        # Calcular estatísticas
        total_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= start_date
        ).scalar() or 0
        
        transaction_count = Transaction.query.filter(
            Transaction.date >= start_date
        ).count()
        
        # Ranking de casinos
        casino_ranking = db.session.query(
            Casino.name,
            func.sum(Transaction.amount).label('total_amount')
        ).join(
            Transaction, Casino.id == Transaction.casino_id
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            Casino.id
        ).order_by(
            func.sum(Transaction.amount).desc()
        ).all()
        
        # Preparar dados para o relatório
        report_data = {
            'title': f'Relatório de Lucros - {period_name}',
            'generated_at': datetime.now().strftime('%d/%m/%Y %H:%M'),
            'period': period_name,
            'start_date': start_date.strftime('%d/%m/%Y'),
            'end_date': datetime.now().strftime('%d/%m/%Y'),
            'summary': {
                'total_profit': total_profit,
                'transaction_count': transaction_count,
                'avg_profit': total_profit / transaction_count if transaction_count > 0 else 0
            },
            'casino_ranking': [
                {
                    'name': name,
                    'amount': float(amount)
                }
                for name, amount in casino_ranking
            ]
        }
        
        # Criar arquivo temporário
        temp_file = tempfile.NamedTemporaryFile(delete=False)
        
        if format_type == 'pdf':
            # Criar PDF usando uma biblioteca como reportlab ou weasyprint
            # Simplificado para este exemplo - apenas exporta como JSON
            with open(temp_file.name, 'w', encoding='utf-8') as jsonfile:
                json.dump(report_data, jsonfile, ensure_ascii=False, indent=2)
            
            # Enviar arquivo
            return send_file(
                temp_file.name,
                as_attachment=True,
                download_name=f'relatorio_{datetime.now().strftime("%Y%m%d")}.json',
                mimetype='application/json'
            )
            
        elif format_type == 'excel':
            # Criar Excel com pandas
            # Simplificado para este exemplo
            df = pd.DataFrame({
                'Métrica': ['Período', 'Data Inicial', 'Data Final', 'Lucro Total', 'Número de Transações', 'Lucro Médio'],
                'Valor': [
                    period_name,
                    start_date.strftime('%d/%m/%Y'),
                    datetime.now().strftime('%d/%m/%Y'),
                    total_profit,
                    transaction_count,
                    total_profit / transaction_count if transaction_count > 0 else 0
                ]
            })
            
            # Adicionar ranking de casinos
            casino_df = pd.DataFrame(report_data['casino_ranking'])
            
            # Salvar no arquivo
            with pd.ExcelWriter(temp_file.name) as writer:
                df.to_excel(writer, sheet_name='Resumo', index=False)
                if not casino_df.empty:
                    casino_df.to_excel(writer, sheet_name='Ranking de Casas', index=False)
            
            # Enviar arquivo
            return send_file(
                temp_file.name,
                as_attachment=True,
                download_name=f'relatorio_{datetime.now().strftime("%Y%m%d")}.xlsx',
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
            
        else:
            return jsonify({'error': 'Formato não suportado. Use pdf ou excel.'}), 400
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        # Limpar arquivo temporário
        if 'temp_file' in locals():
            os.unlink(temp_file.name)

@export_bp.route('/export/backup', methods=['GET'])
def export_backup():
    """Exporta backup completo dos dados"""
    try:
        # Consultar todos os dados
        casinos = Casino.query.all()
        categories = Category.query.all()
        transactions = Transaction.query.all()
        goals = Goal.query.all()
        
        # Preparar dados para backup
        backup_data = {
            'metadata': {
                'version': '1.0',
                'generated_at': datetime.now().isoformat(),
                'description': 'Backup completo do sistema de planilhamento de giros grátis de cassino'
            },
            'casinos': [casino.to_dict() for casino in casinos],
            'categories': [category.to_dict() for category in categories],
            'transactions': [transaction.to_dict() for transaction in transactions],
            'goals': [goal.to_dict() for goal in goals]
        }
        
        # Criar arquivo temporário
        temp_file = tempfile.NamedTemporaryFile(delete=False)
        
        # Salvar backup como JSON
        with open(temp_file.name, 'w', encoding='utf-8') as jsonfile:
            json.dump(backup_data, jsonfile, ensure_ascii=False, indent=2)
        
        # Enviar arquivo
        return send_file(
            temp_file.name,
            as_attachment=True,
            download_name=f'backup_completo_{datetime.now().strftime("%Y%m%d")}.json',
            mimetype='application/json'
        )
            
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        # Limpar arquivo temporário
        if 'temp_file' in locals():
            os.unlink(temp_file.name)
