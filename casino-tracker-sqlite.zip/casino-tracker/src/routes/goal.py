from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
from src.models.transaction import db, Goal
from sqlalchemy import func

goal_bp = Blueprint('goal', __name__)

@goal_bp.route('/goals', methods=['GET'])
def get_goals():
    """Retorna lista de metas com opções de filtro"""
    try:
        # Parâmetros de filtro
        status = request.args.get('status', type=str)
        
        # Construir query base
        query = Goal.query
        
        # Aplicar filtros
        if status:
            query = query.filter(Goal.status == status)
        
        # Executar query
        goals = query.order_by(Goal.end_date.asc()).all()
        
        # Preparar resposta
        goals_data = [goal.to_dict() for goal in goals]
        
        # Adicionar progresso atual para cada meta
        total_balance = db.session.query(func.sum(Transaction.amount)).scalar() or 0
        
        for goal in goals_data:
            goal['current_amount'] = total_balance
            goal['progress'] = min(100, (total_balance / goal['target_amount']) * 100)
        
        return jsonify(goals_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@goal_bp.route('/goals/<int:goal_id>', methods=['GET'])
def get_goal(goal_id):
    """Retorna detalhes de uma meta específica"""
    try:
        goal = Goal.query.get_or_404(goal_id)
        goal_data = goal.to_dict()
        
        # Adicionar progresso atual
        total_balance = db.session.query(func.sum(Transaction.amount)).scalar() or 0
        goal_data['current_amount'] = total_balance
        goal_data['progress'] = min(100, (total_balance / goal.target_amount) * 100)
        
        return jsonify(goal_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@goal_bp.route('/goals', methods=['POST'])
def create_goal():
    """Cria uma nova meta"""
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if not all(key in data for key in ['title', 'target_amount', 'end_date']):
            return jsonify({'error': 'Campos obrigatórios: title, target_amount, end_date'}), 400
        
        # Criar nova meta
        new_goal = Goal(
            title=data['title'],
            target_amount=data['target_amount'],
            start_date=datetime.fromisoformat(data.get('start_date', datetime.now().isoformat())),
            end_date=datetime.fromisoformat(data['end_date']),
            status=data.get('status', 'in_progress')
        )
        
        db.session.add(new_goal)
        db.session.commit()
        
        return jsonify(new_goal.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@goal_bp.route('/goals/<int:goal_id>', methods=['PUT'])
def update_goal(goal_id):
    """Atualiza uma meta existente"""
    try:
        goal = Goal.query.get_or_404(goal_id)
        data = request.json
        
        # Atualizar campos
        if 'title' in data:
            goal.title = data['title']
        if 'target_amount' in data:
            goal.target_amount = data['target_amount']
        if 'start_date' in data:
            goal.start_date = datetime.fromisoformat(data['start_date'])
        if 'end_date' in data:
            goal.end_date = datetime.fromisoformat(data['end_date'])
        if 'status' in data:
            goal.status = data['status']
            if data['status'] == 'completed' and not goal.completed_date:
                goal.completed_date = datetime.now()
        
        db.session.commit()
        
        return jsonify(goal.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@goal_bp.route('/goals/<int:goal_id>', methods=['DELETE'])
def delete_goal(goal_id):
    """Remove uma meta"""
    try:
        goal = Goal.query.get_or_404(goal_id)
        db.session.delete(goal)
        db.session.commit()
        
        return jsonify({'message': 'Meta removida com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
