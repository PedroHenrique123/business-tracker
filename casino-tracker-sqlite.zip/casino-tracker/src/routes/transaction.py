from flask import Blueprint, jsonify, request
from datetime import datetime
from src.models.transaction import db, Transaction, Casino, Category

transaction_bp = Blueprint('transaction', __name__)

@transaction_bp.route('/transactions', methods=['GET'])
def get_transactions():
    """Retorna lista de transações com opções de filtro e paginação"""
    try:
        # Parâmetros de filtro
        page = request.args.get('page', default=1, type=int)
        per_page = request.args.get('per_page', default=10, type=int)
        start_date = request.args.get('start_date', type=str)
        end_date = request.args.get('end_date', type=str)
        casino_id = request.args.get('casino_id', type=int)
        category_id = request.args.get('category_id', type=int)
        sort_by = request.args.get('sort_by', default='date', type=str)
        sort_order = request.args.get('sort_order', default='desc', type=str)
        
        # Construir query base
        query = Transaction.query
        
        # Aplicar filtros
        if start_date:
            query = query.filter(Transaction.date >= datetime.fromisoformat(start_date))
        if end_date:
            query = query.filter(Transaction.date <= datetime.fromisoformat(end_date))
        if casino_id:
            query = query.filter(Transaction.casino_id == casino_id)
        if category_id:
            query = query.filter(Transaction.category_id == category_id)
        
        # Aplicar ordenação
        if sort_by == 'date':
            if sort_order == 'asc':
                query = query.order_by(Transaction.date.asc())
            else:
                query = query.order_by(Transaction.date.desc())
        elif sort_by == 'amount':
            if sort_order == 'asc':
                query = query.order_by(Transaction.amount.asc())
            else:
                query = query.order_by(Transaction.amount.desc())
        elif sort_by == 'casino':
            query = query.join(Casino)
            if sort_order == 'asc':
                query = query.order_by(Casino.name.asc())
            else:
                query = query.order_by(Casino.name.desc())
        
        # Executar paginação
        paginated_transactions = query.paginate(page=page, per_page=per_page)
        
        # Preparar resposta
        transactions_data = [transaction.to_dict() for transaction in paginated_transactions.items]
        
        return jsonify({
            'transactions': transactions_data,
            'pagination': {
                'total': paginated_transactions.total,
                'pages': paginated_transactions.pages,
                'page': page,
                'per_page': per_page,
                'has_next': paginated_transactions.has_next,
                'has_prev': paginated_transactions.has_prev
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['GET'])
def get_transaction(transaction_id):
    """Retorna detalhes de uma transação específica"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        return jsonify(transaction.to_dict())
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions', methods=['POST'])
def create_transaction():
    """Cria uma nova transação"""
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if not all(key in data for key in ['amount', 'casino_id']):
            return jsonify({'error': 'Campos obrigatórios: amount, casino_id'}), 400
        
        # Criar nova transação
        new_transaction = Transaction(
            amount=data['amount'],
            date=datetime.fromisoformat(data.get('date', datetime.now().isoformat())),
            notes=data.get('notes'),
            casino_id=data['casino_id'],
            category_id=data.get('category_id')
        )
        
        db.session.add(new_transaction)
        db.session.commit()
        
        return jsonify(new_transaction.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['PUT'])
def update_transaction(transaction_id):
    """Atualiza uma transação existente"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        data = request.json
        
        # Atualizar campos
        if 'amount' in data:
            transaction.amount = data['amount']
        if 'date' in data:
            transaction.date = datetime.fromisoformat(data['date'])
        if 'notes' in data:
            transaction.notes = data['notes']
        if 'casino_id' in data:
            transaction.casino_id = data['casino_id']
        if 'category_id' in data:
            transaction.category_id = data['category_id']
        
        db.session.commit()
        
        return jsonify(transaction.to_dict())
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/transactions/<int:transaction_id>', methods=['DELETE'])
def delete_transaction(transaction_id):
    """Remove uma transação"""
    try:
        transaction = Transaction.query.get_or_404(transaction_id)
        db.session.delete(transaction)
        db.session.commit()
        
        return jsonify({'message': 'Transação removida com sucesso'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Rotas para Casinos
@transaction_bp.route('/casinos', methods=['GET'])
def get_casinos():
    """Retorna lista de casas de apostas"""
    try:
        casinos = Casino.query.all()
        return jsonify([casino.to_dict() for casino in casinos])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/casinos', methods=['POST'])
def create_casino():
    """Cria uma nova casa de apostas"""
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if 'name' not in data:
            return jsonify({'error': 'Campo obrigatório: name'}), 400
        
        # Verificar se já existe
        existing = Casino.query.filter_by(name=data['name']).first()
        if existing:
            return jsonify({'error': 'Casa de apostas já existe'}), 400
        
        # Criar nova casa
        new_casino = Casino(
            name=data['name'],
            color=data.get('color', '#00E676')
        )
        
        db.session.add(new_casino)
        db.session.commit()
        
        return jsonify(new_casino.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Rotas para Categorias
@transaction_bp.route('/categories', methods=['GET'])
def get_categories():
    """Retorna lista de categorias"""
    try:
        categories = Category.query.all()
        return jsonify([category.to_dict() for category in categories])
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@transaction_bp.route('/categories', methods=['POST'])
def create_category():
    """Cria uma nova categoria"""
    try:
        data = request.json
        
        # Validar dados obrigatórios
        if 'name' not in data:
            return jsonify({'error': 'Campo obrigatório: name'}), 400
        
        # Verificar se já existe
        existing = Category.query.filter_by(name=data['name']).first()
        if existing:
            return jsonify({'error': 'Categoria já existe'}), 400
        
        # Criar nova categoria
        new_category = Category(
            name=data['name']
        )
        
        db.session.add(new_category)
        db.session.commit()
        
        return jsonify(new_category.to_dict()), 201
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500
