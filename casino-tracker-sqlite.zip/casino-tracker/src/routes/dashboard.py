from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
from src.models.transaction import db, Transaction, Casino, Category, Goal
from sqlalchemy import func, extract

api_bp = Blueprint('api', __name__)

# Rotas para Dashboard
@api_bp.route('/dashboard/summary', methods=['GET'])
def get_dashboard_summary():
    """Retorna um resumo dos dados para o dashboard principal"""
    try:
        # Data atual
        today = datetime.now().date()
        start_of_today = datetime.combine(today, datetime.min.time())
        start_of_week = datetime.combine(today - timedelta(days=today.weekday()), datetime.min.time())
        start_of_month = datetime.combine(datetime(today.year, today.month, 1), datetime.min.time())
        
        # Cálculo de saldo total
        total_balance = db.session.query(func.sum(Transaction.amount)).scalar() or 0
        
        # Lucro do dia
        today_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= start_of_today
        ).scalar() or 0
        
        # Lucro da semana
        week_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= start_of_week
        ).scalar() or 0
        
        # Lucro do mês
        month_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= start_of_month
        ).scalar() or 0
        
        # Última transação
        last_transaction = Transaction.query.order_by(Transaction.date.desc()).first()
        last_transaction_data = last_transaction.to_dict() if last_transaction else None
        
        # Meta atual
        current_goal = Goal.query.filter_by(status='in_progress').order_by(Goal.end_date).first()
        current_goal_data = None
        
        if current_goal:
            current_goal_data = current_goal.to_dict()
            # Calcular progresso
            current_goal_data['current_amount'] = total_balance
            current_goal_data['progress'] = min(100, (total_balance / current_goal.target_amount) * 100)
        
        return jsonify({
            'total_balance': total_balance,
            'today_profit': today_profit,
            'week_profit': week_profit,
            'month_profit': month_profit,
            'last_transaction': last_transaction_data,
            'current_goal': current_goal_data
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/dashboard/growth-chart', methods=['GET'])
def get_growth_chart():
    """Retorna dados para o gráfico de crescimento da banca"""
    try:
        days = request.args.get('days', default=30, type=int)
        
        # Data inicial para o período solicitado
        start_date = datetime.now() - timedelta(days=days)
        
        # Consultar transações agrupadas por dia
        daily_transactions = db.session.query(
            func.date(Transaction.date).label('date'),
            func.sum(Transaction.amount).label('amount')
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            func.date(Transaction.date)
        ).order_by(
            func.date(Transaction.date)
        ).all()
        
        # Criar dicionário de datas e valores
        date_amounts = {str(date): float(amount) for date, amount in daily_transactions}
        
        # Preencher datas faltantes com valor zero
        chart_data = []
        running_total = 0
        
        # Obter saldo antes do período
        previous_balance = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date < start_date
        ).scalar() or 0
        running_total = previous_balance
        
        # Gerar série temporal completa
        current_date = start_date.date()
        end_date = datetime.now().date()
        
        while current_date <= end_date:
            current_date_str = str(current_date)
            daily_amount = date_amounts.get(current_date_str, 0)
            running_total += daily_amount
            
            chart_data.append({
                'date': current_date_str,
                'amount': daily_amount,
                'balance': running_total
            })
            
            current_date += timedelta(days=1)
        
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/dashboard/weekly-profit', methods=['GET'])
def get_weekly_profit():
    """Retorna dados para o gráfico de lucros diários da semana atual"""
    try:
        # Data atual
        today = datetime.now().date()
        start_of_week = today - timedelta(days=today.weekday())
        
        # Dias da semana em português
        weekdays = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
        
        # Consultar transações agrupadas por dia da semana
        daily_profits = db.session.query(
            extract('dow', Transaction.date).label('weekday'),
            func.sum(Transaction.amount).label('amount')
        ).filter(
            func.date(Transaction.date) >= start_of_week
        ).group_by(
            extract('dow', Transaction.date)
        ).all()
        
        # Converter para dicionário
        weekday_profits = {int(weekday): float(amount) for weekday, amount in daily_profits}
        
        # Preencher todos os dias da semana
        chart_data = []
        for i in range(7):
            day_date = start_of_week + timedelta(days=i)
            # Ajustar índice do dia da semana (0=Segunda na nossa lista, mas pode ser diferente no banco)
            weekday_index = i
            chart_data.append({
                'weekday': weekdays[i],
                'date': str(day_date),
                'amount': weekday_profits.get(weekday_index, 0)
            })
        
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/dashboard/casino-distribution', methods=['GET'])
def get_casino_distribution():
    """Retorna dados para o gráfico de distribuição por casa de apostas"""
    try:
        # Período opcional
        days = request.args.get('days', default=30, type=int)
        start_date = datetime.now() - timedelta(days=days)
        
        # Consultar transações agrupadas por casino
        casino_profits = db.session.query(
            Casino.name,
            Casino.color,
            func.sum(Transaction.amount).label('amount')
        ).join(
            Transaction, Casino.id == Transaction.casino_id
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            Casino.id
        ).order_by(
            func.sum(Transaction.amount).desc()
        ).all()
        
        # Converter para lista de dicionários
        chart_data = [
            {
                'casino': name,
                'color': color,
                'amount': float(amount)
            }
            for name, color, amount in casino_profits
        ]
        
        return jsonify(chart_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/dashboard/recent-transactions', methods=['GET'])
def get_recent_transactions():
    """Retorna as transações mais recentes para o dashboard"""
    try:
        limit = request.args.get('limit', default=5, type=int)
        
        # Consultar transações recentes
        recent_transactions = Transaction.query.order_by(
            Transaction.date.desc()
        ).limit(limit).all()
        
        # Converter para dicionários
        transactions_data = [transaction.to_dict() for transaction in recent_transactions]
        
        return jsonify(transactions_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500
