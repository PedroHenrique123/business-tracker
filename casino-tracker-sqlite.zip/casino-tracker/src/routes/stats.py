from flask import Blueprint, jsonify, request
from datetime import datetime, timedelta
from src.models.transaction import db, Transaction, Casino, Category
from sqlalchemy import func, extract, desc

stats_bp = Blueprint('stats', __name__)

@stats_bp.route('/stats/period-summary', methods=['GET'])
def get_period_summary():
    """Retorna resumo estatístico para um período específico"""
    try:
        # Parâmetros de período
        period = request.args.get('period', default='month', type=str)
        
        # Definir data inicial com base no período
        today = datetime.now().date()
        if period == 'week':
            start_date = datetime.combine(today - timedelta(days=today.weekday()), datetime.min.time())
        elif period == 'month':
            start_date = datetime.combine(datetime(today.year, today.month, 1), datetime.min.time())
        elif period == 'year':
            start_date = datetime.combine(datetime(today.year, 1, 1), datetime.min.time())
        elif period == 'all':
            start_date = datetime(1900, 1, 1)  # Data bem antiga para pegar tudo
        else:
            # Período personalizado (dias)
            days = int(period)
            start_date = datetime.now() - timedelta(days=days)
        
        # Calcular estatísticas
        total_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= start_date
        ).scalar() or 0
        
        transaction_count = Transaction.query.filter(
            Transaction.date >= start_date
        ).count()
        
        avg_profit = total_profit / transaction_count if transaction_count > 0 else 0
        
        # Maior lucro
        max_profit = db.session.query(func.max(Transaction.amount)).filter(
            Transaction.date >= start_date
        ).scalar() or 0
        
        # Dia com maior lucro
        best_day_result = db.session.query(
            func.date(Transaction.date).label('date'),
            func.sum(Transaction.amount).label('amount')
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            func.date(Transaction.date)
        ).order_by(
            func.sum(Transaction.amount).desc()
        ).first()
        
        best_day = {
            'date': str(best_day_result[0]) if best_day_result else None,
            'amount': float(best_day_result[1]) if best_day_result else 0
        }
        
        # Casa de apostas mais lucrativa
        best_casino_result = db.session.query(
            Casino.name,
            func.sum(Transaction.amount).label('amount')
        ).join(
            Transaction, Casino.id == Transaction.casino_id
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            Casino.id
        ).order_by(
            func.sum(Transaction.amount).desc()
        ).first()
        
        best_casino = {
            'name': best_casino_result[0] if best_casino_result else None,
            'amount': float(best_casino_result[1]) if best_casino_result else 0
        }
        
        return jsonify({
            'period': period,
            'start_date': start_date.isoformat(),
            'end_date': datetime.now().isoformat(),
            'total_profit': total_profit,
            'transaction_count': transaction_count,
            'avg_profit': avg_profit,
            'max_profit': max_profit,
            'best_day': best_day,
            'best_casino': best_casino
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stats_bp.route('/stats/casino-ranking', methods=['GET'])
def get_casino_ranking():
    """Retorna ranking de casas de apostas por lucro"""
    try:
        # Parâmetros de período
        days = request.args.get('days', default=30, type=int)
        limit = request.args.get('limit', default=10, type=int)
        
        # Data inicial para o período solicitado
        start_date = datetime.now() - timedelta(days=days)
        
        # Consultar ranking de casinos
        casino_ranking = db.session.query(
            Casino.id,
            Casino.name,
            Casino.color,
            func.sum(Transaction.amount).label('total_amount'),
            func.count(Transaction.id).label('transaction_count'),
            func.avg(Transaction.amount).label('avg_amount')
        ).join(
            Transaction, Casino.id == Transaction.casino_id
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            Casino.id
        ).order_by(
            func.sum(Transaction.amount).desc()
        ).limit(limit).all()
        
        # Converter para lista de dicionários
        ranking_data = [
            {
                'id': id,
                'name': name,
                'color': color,
                'total_amount': float(total),
                'transaction_count': count,
                'avg_amount': float(avg)
            }
            for id, name, color, total, count, avg in casino_ranking
        ]
        
        return jsonify(ranking_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stats_bp.route('/stats/weekday-heatmap', methods=['GET'])
def get_weekday_heatmap():
    """Retorna dados para o gráfico de calor por dia da semana"""
    try:
        # Parâmetros de período
        days = request.args.get('days', default=90, type=int)
        
        # Data inicial para o período solicitado
        start_date = datetime.now() - timedelta(days=days)
        
        # Dias da semana em português
        weekdays = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']
        
        # Consultar transações agrupadas por dia da semana
        weekday_data = db.session.query(
            extract('dow', Transaction.date).label('weekday'),
            func.sum(Transaction.amount).label('amount'),
            func.count(Transaction.id).label('count')
        ).filter(
            Transaction.date >= start_date
        ).group_by(
            extract('dow', Transaction.date)
        ).all()
        
        # Converter para dicionário
        heatmap_data = []
        for i in range(7):
            # Procurar dados para este dia da semana
            day_data = next((data for data in weekday_data if int(data[0]) == i), None)
            
            heatmap_data.append({
                'weekday': weekdays[i],
                'weekday_index': i,
                'amount': float(day_data[1]) if day_data else 0,
                'count': int(day_data[2]) if day_data else 0
            })
        
        # Ordenar por valor para identificar os melhores dias
        sorted_data = sorted(heatmap_data, key=lambda x: x['amount'], reverse=True)
        
        return jsonify({
            'heatmap': heatmap_data,
            'best_weekday': sorted_data[0] if sorted_data else None
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stats_bp.route('/stats/monthly-comparison', methods=['GET'])
def get_monthly_comparison():
    """Retorna comparação entre o mês atual e o anterior"""
    try:
        # Data atual
        today = datetime.now().date()
        
        # Mês atual
        current_month_start = datetime(today.year, today.month, 1)
        
        # Mês anterior
        if today.month == 1:
            prev_month_start = datetime(today.year - 1, 12, 1)
            prev_month_end = datetime(today.year, 1, 1) - timedelta(days=1)
        else:
            prev_month_start = datetime(today.year, today.month - 1, 1)
            prev_month_end = current_month_start - timedelta(days=1)
        
        # Calcular lucro do mês atual
        current_month_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= current_month_start
        ).scalar() or 0
        
        # Calcular lucro do mês anterior
        prev_month_profit = db.session.query(func.sum(Transaction.amount)).filter(
            Transaction.date >= prev_month_start,
            Transaction.date <= prev_month_end
        ).scalar() or 0
        
        # Calcular variação percentual
        if prev_month_profit == 0:
            percent_change = 100 if current_month_profit > 0 else 0
        else:
            percent_change = ((current_month_profit - prev_month_profit) / abs(prev_month_profit)) * 100
        
        return jsonify({
            'current_month': {
                'name': current_month_start.strftime('%B'),
                'start_date': current_month_start.isoformat(),
                'end_date': today.isoformat(),
                'profit': current_month_profit
            },
            'previous_month': {
                'name': prev_month_start.strftime('%B'),
                'start_date': prev_month_start.isoformat(),
                'end_date': prev_month_end.isoformat(),
                'profit': prev_month_profit
            },
            'percent_change': percent_change
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@stats_bp.route('/stats/trend-analysis', methods=['GET'])
def get_trend_analysis():
    """Retorna análise de tendência de lucros"""
    try:
        # Parâmetros
        months = request.args.get('months', default=6, type=int)
        
        # Data inicial
        today = datetime.now().date()
        start_date = datetime(today.year, today.month, 1) - timedelta(days=30 * (months - 1))
        
        # Consultar lucros mensais
        monthly_profits = []
        current_date = start_date
        
        while current_date <= datetime(today.year, today.month, 1):
            # Definir início e fim do mês
            month_start = current_date
            if current_date.month == 12:
                month_end = datetime(current_date.year + 1, 1, 1) - timedelta(days=1)
            else:
                month_end = datetime(current_date.year, current_date.month + 1, 1) - timedelta(days=1)
            
            # Limitar o fim ao dia atual
            if month_end > today:
                month_end = today
            
            # Calcular lucro do mês
            month_profit = db.session.query(func.sum(Transaction.amount)).filter(
                Transaction.date >= month_start,
                Transaction.date <= datetime.combine(month_end, datetime.max.time())
            ).scalar() or 0
            
            monthly_profits.append({
                'month': month_start.strftime('%Y-%m'),
                'month_name': month_start.strftime('%b/%Y'),
                'profit': float(month_profit)
            })
            
            # Avançar para o próximo mês
            if current_date.month == 12:
                current_date = datetime(current_date.year + 1, 1, 1)
            else:
                current_date = datetime(current_date.year, current_date.month + 1, 1)
        
        # Calcular tendência (crescimento médio mensal)
        if len(monthly_profits) > 1:
            first_month = monthly_profits[0]['profit']
            last_month = monthly_profits[-1]['profit']
            months_count = len(monthly_profits)
            
            if first_month != 0:
                total_growth = ((last_month / first_month) - 1) * 100
                monthly_growth = total_growth / (months_count - 1)
            else:
                monthly_growth = 0
        else:
            monthly_growth = 0
        
        return jsonify({
            'monthly_profits': monthly_profits,
            'trend': {
                'monthly_growth_percent': monthly_growth,
                'is_positive': monthly_growth >= 0
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500
