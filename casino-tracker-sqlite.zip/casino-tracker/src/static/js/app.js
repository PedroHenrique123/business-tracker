// Configuração inicial e variáveis globais
document.addEventListener('DOMContentLoaded', function() {
    // Referências aos elementos DOM
    const addTransactionBtn = document.getElementById('add-transaction-btn');
    const transactionModal = document.getElementById('transaction-modal');
    const closeBtn = transactionModal.querySelector('.close-btn');
    const cancelBtn = transactionModal.querySelector('.cancel-btn');
    const transactionForm = document.getElementById('transaction-form');

    // Configuração dos gráficos
    setupCharts();

    // Event listeners para o modal
    addTransactionBtn.addEventListener('click', function() {
        transactionModal.classList.add('active');
    });

    closeBtn.addEventListener('click', function() {
        transactionModal.classList.remove('active');
    });

    cancelBtn.addEventListener('click', function() {
        transactionModal.classList.remove('active');
    });

    // Fechar modal ao clicar fora dele
    window.addEventListener('click', function(event) {
        if (event.target === transactionModal) {
            transactionModal.classList.remove('active');
        }
    });

    // Manipulação do formulário
    transactionForm.addEventListener('submit', function(event) {
        event.preventDefault();
        
        // Coletar dados do formulário
        const formData = {
            date: document.getElementById('transaction-date').value,
            casino_id: document.getElementById('transaction-casino').value,
            amount: document.getElementById('transaction-amount').value,
            category_id: document.getElementById('transaction-category').value || null,
            notes: document.getElementById('transaction-notes').value || null
        };
        
        // Enviar dados para a API (simulado)
        console.log('Enviando dados:', formData);
        
        // Simular sucesso
        showNotification('Transação adicionada com sucesso!', 'success');
        transactionModal.classList.remove('active');
        transactionForm.reset();
        
        // Em um cenário real, faríamos uma chamada fetch para a API
        // e atualizaríamos a UI com os novos dados
    });

    // Carregar dados iniciais
    loadDashboardData();
});

// Função para configurar os gráficos
function setupCharts() {
    // Gráfico de crescimento da banca
    const growthCtx = document.createElement('canvas');
    document.getElementById('growth-chart').appendChild(growthCtx);
    
    const growthChart = new Chart(growthCtx, {
        type: 'line',
        data: {
            labels: ['01/05', '05/05', '10/05', '15/05', '20/05', '25/05', '27/05'],
            datasets: [{
                label: 'Saldo',
                data: [2000, 2300, 2800, 3200, 4100, 5000, 5432],
                borderColor: '#00E676',
                backgroundColor: 'rgba(0, 230, 118, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#1E1E1E',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderColor: '#00E676',
                    borderWidth: 1,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `R$ ${context.raw.toFixed(2)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        color: 'rgba(112, 112, 112, 0.1)'
                    },
                    ticks: {
                        color: '#B0B0B0'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(112, 112, 112, 0.1)'
                    },
                    ticks: {
                        color: '#B0B0B0',
                        callback: function(value) {
                            return `R$ ${value}`;
                        }
                    }
                }
            }
        }
    });

    // Gráfico de lucros da semana
    const weeklyCtx = document.createElement('canvas');
    document.getElementById('weekly-chart').appendChild(weeklyCtx);
    
    const weeklyChart = new Chart(weeklyCtx, {
        type: 'bar',
        data: {
            labels: ['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb', 'Dom'],
            datasets: [{
                data: [120, 150, 100, 180, 200, 50, 50],
                backgroundColor: '#2979FF',
                borderRadius: 4
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: '#1E1E1E',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderColor: '#2979FF',
                    borderWidth: 1,
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `R$ ${context.raw.toFixed(2)}`;
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        color: '#B0B0B0'
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(112, 112, 112, 0.1)'
                    },
                    ticks: {
                        color: '#B0B0B0',
                        callback: function(value) {
                            return `R$ ${value}`;
                        }
                    }
                }
            }
        }
    });

    // Gráfico de distribuição por casa
    const distributionCtx = document.createElement('canvas');
    document.getElementById('casino-distribution-chart').appendChild(distributionCtx);
    
    const distributionChart = new Chart(distributionCtx, {
        type: 'doughnut',
        data: {
            labels: ['Betano', 'Bet365', 'Sportingbet', 'Pixbet', 'Outros'],
            datasets: [{
                data: [35, 25, 20, 15, 5],
                backgroundColor: [
                    '#00E676',
                    '#2979FF',
                    '#FF3D00',
                    '#AA00FF',
                    '#FFEA00'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'right',
                    labels: {
                        color: '#B0B0B0',
                        padding: 10,
                        usePointStyle: true,
                        pointStyle: 'circle'
                    }
                },
                tooltip: {
                    backgroundColor: '#1E1E1E',
                    titleColor: '#FFFFFF',
                    bodyColor: '#B0B0B0',
                    borderWidth: 1,
                    displayColors: true,
                    callbacks: {
                        label: function(context) {
                            return `${context.label}: ${context.raw}%`;
                        }
                    }
                }
            }
        }
    });
}

// Função para carregar dados do dashboard
function loadDashboardData() {
    // Em um cenário real, faríamos chamadas fetch para a API
    // e atualizaríamos a UI com os dados recebidos
    
    // Exemplo de chamada API (simulada)
    console.log('Carregando dados do dashboard...');
    
    // Simular carregamento de dados
    setTimeout(function() {
        console.log('Dados carregados com sucesso!');
    }, 1000);
}

// Função para exibir notificações
function showNotification(message, type = 'info') {
    // Criar elemento de notificação
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    // Adicionar ao DOM
    document.body.appendChild(notification);
    
    // Animar entrada
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Remover após alguns segundos
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}

// Funções auxiliares para formatação
function formatCurrency(value) {
    return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
    }).format(value);
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('pt-BR').format(date);
}
