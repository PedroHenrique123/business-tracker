# Paleta de Cores e Design Visual

## Paleta Principal
- **Fundo Principal**: #121212 (Preto quase puro)
- **Fundo Secundário**: #1E1E1E (Cinza muito escuro)
- **Fundo de Cards**: #252525 (Cinza escuro)
- **Destaque Primário**: #00E676 (Verde neon)
- **Destaque Secundário**: #FF3D00 (Laranja vibrante)
- **Destaque Terciário**: #2979FF (Azul elétrico)
- **Texto Principal**: #FFFFFF (Branco)
- **Texto Secundário**: #B0B0B0 (Cinza claro)
- **Texto Terciário**: #707070 (Cinza médio)

## Cores para Gráficos
- **Lucro Positivo**: #00E676 (Verde neon)
- **Lucro Negativo**: #FF3D00 (Laranja vibrante)
- **Linha de Tendência**: #2979FF (Azul elétrico)
- **Cores para Casas de Apostas**:
  - #00E676 (Verde neon)
  - #FF3D00 (Laranja vibrante)
  - #2979FF (Azul elétrico)
  - #FFEA00 (Amarelo vibrante)
  - #AA00FF (Roxo vibrante)
  - #00B0FF (Azul ciano)
  - #FF9100 (Laranja âmbar)
  - #76FF03 (Verde limão)

## Tipografia
- **Fonte Principal**: 'Roboto', sans-serif
- **Fonte para Números**: 'Roboto Mono', monospace
- **Tamanhos**:
  - Títulos: 24px
  - Subtítulos: 18px
  - Texto normal: 14px
  - Texto pequeno: 12px
  - Valores grandes (destaque): 32px

## Elementos de UI
- **Bordas de Cards**: Raio de 8px, sem borda visível
- **Sombras**: Sutil, 0px 4px 6px rgba(0, 0, 0, 0.3)
- **Botões Primários**: Fundo #00E676, texto #121212, raio 4px
- **Botões Secundários**: Fundo transparente, borda #00E676, texto #00E676, raio 4px
- **Botões de Ação Negativa**: Fundo #FF3D00, texto #121212, raio 4px
- **Inputs**: Fundo #1E1E1E, borda inferior #707070, foco #00E676
- **Switches/Toggles**: Fundo inativo #707070, ativo #00E676

## Ícones
- Estilo minimalista, linha fina
- Tamanho padrão: 20px x 20px
- Cor padrão: #B0B0B0
- Cor de destaque: #00E676

## Feedback Visual
- **Sucesso**: Flash sutil de #00E676
- **Erro**: Flash sutil de #FF3D00
- **Carregamento**: Spinner minimalista em #00E676
- **Hover**: Leve aumento de brilho (opacity 0.8 para 1.0)

## Responsividade
- **Breakpoints**:
  - Mobile: < 768px
  - Tablet: 768px - 1024px
  - Desktop: > 1024px
- **Layout Mobile**: Empilhado, cards em largura total
- **Layout Tablet**: Grid de 2 colunas
- **Layout Desktop**: Grid de 3-4 colunas
