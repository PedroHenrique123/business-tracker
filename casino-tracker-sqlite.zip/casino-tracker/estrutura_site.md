# Estrutura e Funcionalidades do Site de Planilhamento de Giros Grátis de Cassino

## Páginas Principais

### 1. Dashboard Principal
- **Objetivo**: Fornecer uma visão geral rápida e completa da situação financeira
- **Componentes**:
  - Card de saldo atual da banca
  - Card de lucro do dia atual
  - Card de lucro da semana atual
  - Card de lucro do mês atual
  - Card do último valor ganho (com casa de apostas)
  - Gráfico de linha mostrando crescimento da banca nos últimos 30 dias
  - Gráfico de barras com lucros diários da semana atual
  - Botão de destaque para adicionar novo lucro
  - Resumo das últimas 5 transações
  - Indicador de progresso para meta atual

### 2. Histórico de Transações
- **Objetivo**: Listar todas as transações realizadas com filtros e ordenação
- **Componentes**:
  - Tabela de transações com colunas para data, casa de apostas, valor, observações
  - Filtros por período (dia, semana, mês, personalizado)
  - Filtros por casa de apostas
  - Ordenação por data, valor, casa de apostas
  - Opção para editar ou excluir transações
  - Paginação para navegação em histórico extenso
  - Totalizadores por período filtrado

### 3. Estatísticas e Análises
- **Objetivo**: Fornecer insights detalhados sobre o desempenho
- **Componentes**:
  - Gráfico de pizza mostrando distribuição de lucros por casa de apostas
  - Gráfico de calor mostrando dias da semana e horários mais lucrativos
  - Gráfico de linha com tendência de crescimento da banca
  - Estatísticas de média de lucro diário, semanal e mensal
  - Ranking das casas de apostas mais lucrativas
  - Comparativo de desempenho entre períodos (mês atual vs. anterior)

### 4. Metas e Objetivos
- **Objetivo**: Definir e acompanhar metas financeiras
- **Componentes**:
  - Formulário para criar novas metas (valor alvo, prazo)
  - Lista de metas ativas e concluídas
  - Gráficos de progresso para cada meta
  - Projeções baseadas no ritmo atual de lucros
  - Histórico de metas concluídas

### 5. Configurações e Exportação
- **Objetivo**: Personalizar o sistema e fazer backup dos dados
- **Componentes**:
  - Opções para exportar dados em CSV, Excel ou PDF
  - Configuração de casas de apostas (adicionar, editar, remover)
  - Personalização de categorias de transações
  - Opções de tema (variações de cores escuras)
  - Configurações de notificações e lembretes

## Estrutura de Dados

### Transação
- ID (único)
- Data e hora
- Casa de apostas
- Valor
- Observações (opcional)
- Categoria (opcional)

### Casa de Apostas
- ID (único)
- Nome
- Cor associada (para gráficos)
- Logo/ícone (opcional)

### Meta
- ID (único)
- Título
- Valor alvo
- Data inicial
- Data final (prazo)
- Status (em andamento, concluída, cancelada)

## Funcionalidades Detalhadas

### Registro de Lucros
- Formulário intuitivo para adicionar novos lucros
- Campos obrigatórios: data, casa de apostas, valor
- Campos opcionais: observações, categoria
- Validação de dados para evitar erros
- Confirmação visual após registro bem-sucedido

### Cálculos Automáticos
- Saldo atual da banca (soma de todos os lucros)
- Lucro do dia (soma dos lucros do dia atual)
- Lucro da semana (soma dos lucros da semana atual)
- Lucro do mês (soma dos lucros do mês atual)
- Médias diárias, semanais e mensais
- Projeções de crescimento baseadas em tendências

### Visualizações Gráficas
- Gráfico de linha para evolução do saldo ao longo do tempo
- Gráfico de barras para comparação de lucros por período
- Gráfico de pizza para distribuição por casa de apostas
- Gráfico de calor para identificar padrões temporais
- Indicadores visuais de progresso para metas

### Sistema de Metas
- Definição de metas de lucro com prazos
- Acompanhamento visual do progresso
- Notificações de metas próximas de conclusão
- Histórico de metas concluídas com tempo de realização

### Exportação e Backup
- Exportação de dados em formatos CSV, Excel e PDF
- Opções para selecionar períodos específicos para exportação
- Geração de relatórios detalhados com gráficos
- Backup automático dos dados no navegador (localStorage)

### Análise de Tendências
- Identificação de dias da semana mais lucrativos
- Identificação de horários mais lucrativos
- Análise de desempenho por casa de apostas
- Comparativo entre períodos (semana atual vs. anterior, mês atual vs. anterior)

## Tecnologias Propostas

### Frontend
- HTML5, CSS3, JavaScript
- Framework: React.js para componentes reutilizáveis
- Biblioteca de gráficos: Chart.js para visualizações
- Armazenamento: localStorage para persistência de dados
- Design responsivo para funcionar em dispositivos móveis e desktop

### Estilo e Design
- Paleta de cores escuras com destaques chamativos
- Interface minimalista e clean
- Tipografia de alta legibilidade
- Ícones intuitivos
- Animações sutis para feedback visual
